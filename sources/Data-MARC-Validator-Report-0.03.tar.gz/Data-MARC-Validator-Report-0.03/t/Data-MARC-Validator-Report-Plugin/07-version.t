use strict;
use warnings;

use Data::MARC::Validator::Report::Plugin;
use Test::More 'tests' => 2;
use Test::NoWarnings;

# Test.
my $obj = Data::MARC::Validator::Report::Plugin->new(
	'module_name' => 'MARC::Validator::Plugin::Foo',
	'name' => 'foo',
	'version' => '0.01',
);
my $ret = $obj->version;
is($ret, 0.01, 'Get version (0.01).');
