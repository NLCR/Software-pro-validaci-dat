use strict;
use warnings;

use App::MARC::Validator;
use English;
use File::Object;
use File::Spec::Functions qw(abs2rel);
use Test::More 'tests' => 7;
use Test::NoWarnings;
use Test::Output;
use Test::Warn 0.31;

# Data directory.
my $data_dir = File::Object->new->up->dir('data');

# Test.
@ARGV = (
	'-l',
);
my $right_ret = "List of plugins:\n- MARC::Validator";
stdout_like(
	sub {
		App::MARC::Validator->new->run;
		return;
	},
	qr{^$right_ret},
	'List plugins (-l).',
);

# Test.
@ARGV = (
	'-p',
	'-u',
	'plugin:MARC::Validator::Plugin::Field008',
	$data_dir->file('cnb003755915.xml')->s,
);
$right_ret = <<'END';
{
   "field_008" : {
      "checks" : {
         "not_valid" : {
            "1426868" : [
               {
                  "error" : "Bad length of MARC leader.",
                  "params" : {
                     "Length" : 23
                  }
               }
            ]
         }
      },
END
chomp $right_ret;
stdout_like(
	sub {
		App::MARC::Validator->new->run;
		return;
	},
	qr{^\Q$right_ret\E},
	'Process MARC record with shorter leader that 24 characters.',
);

# Test.
@ARGV = (
	'-h',
);
$right_ret = help();
stderr_is(
	sub {
		App::MARC::Validator->new->run;
		return;
	},
	$right_ret,
	'Run help (-h).',
);

# Test.
@ARGV = ();
$right_ret = help();
stderr_is(
	sub {
		App::MARC::Validator->new->run;
		return;
	},
	$right_ret,
	'Run help (no arguments).',
);

# Test.
@ARGV = (
	'-x',
);
$right_ret = help();
stderr_is(
	sub {
		warning_is { App::MARC::Validator->new->run; } "Unknown option: x\n",
			'Warning about bad argument';
		return;
	},
	$right_ret,
	'Run help (-x - bad option).',
);

sub help {
	my $script = abs2rel(__FILE__);
	if ($OSNAME eq 'MSWin32') {
		$script =~ s/\\/\//msg;
	}
	my $help = <<"END";
Usage: $script [-d] [-f] [-h] [-i id] [-l] [-o output_file] [-p] [-r] [-u use_string] [-v] [--version] marc_xml_file..
	-d		Debug mode.
	-f		List of filter plugins.
	-h		Print help.
	-i id		Record identifier (default value is 001).
	-l		List of plugins.
	-o output_file	Output file (default is STDOUT).
	-p		Pretty print JSON output.
	-r		Recommendations.
	-u use_string	Use string to prefer plugin or filter (default situation is use all).
			e.g. plugin:MARC::Validator::Plugin::Field008
	-v		Verbose mode.
	--version	Print version.
	marc_xml_file..	MARC XML file(s).
END

	return $help;
}
