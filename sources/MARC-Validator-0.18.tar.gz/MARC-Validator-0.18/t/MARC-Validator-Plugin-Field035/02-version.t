use strict;
use warnings;

use MARC::Validator::Plugin::Field035;
use Test::More 'tests' => 2;
use Test::NoWarnings;

# Test.
is($MARC::Validator::Plugin::Field035::VERSION, 0.18, 'Version.');
