use strict;
use warnings;

use MARC::Validator::Plugin::Field500;
use Test::More 'tests' => 2;
use Test::NoWarnings;

# Test.
is($MARC::Validator::Plugin::Field500::VERSION, 0.21, 'Version.');
