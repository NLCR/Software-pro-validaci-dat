use strict;
use warnings;

use MARC::Validator::Filter::Plugin::AACR2;
use Test::More 'tests' => 2;
use Test::NoWarnings;

# Test.
is($MARC::Validator::Filter::Plugin::AACR2::VERSION, 0.01, 'Version.');
