use strict;
use warnings;

use Test::More 'tests' => 3;
use Test::NoWarnings;

BEGIN {

	# Test.
	use_ok('Business::UDC::Tokenizer');
}

# Test.
require_ok('Business::UDC::Tokenizer');
